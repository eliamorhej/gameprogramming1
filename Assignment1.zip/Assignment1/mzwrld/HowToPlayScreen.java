// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class HowToPlayScreen extends World
{
    private GreenfootSound game_music =  new GreenfootSound("Starting.wav");
    public int counter = 90;
    private int delayCounter = 50;

    /**
     * Constructor for objects of class HowToPlayScreen.
     */
    public HowToPlayScreen()
    {
        super(900, 750, 1);
    }

    /**
     * 
     */
    public void act()
    {
        delayCounter = delayCounter - 1;
        showTxt();
        if (delayCounter < 0 && isSpacePressed()) {
            World mazeWorld =  new MazeWorld();
            Greenfoot.setWorld(mazeWorld);
            stopped();
            mazeWorld.started();
        }
    }

    /**
     * 
     */
    public void showTxt()
    {
        if (counter > 0) {
            this.showText("Press Space to Play", 450, 700);
        }
        else {
            this.showText("", 450, 700);
        }
        counter = counter - 1;
        
        if (counter < -90) {
            counter = 90;
        }
    }

    /**
     * 
     */
    public void started()
    {
        game_music.playLoop();
    }

    /**
     * 
     */
    public void stopped()
    {
        game_music.stop();
    }

    /**
     * 
     */
    public boolean isSpacePressed()
    {
        if (Greenfoot.isKeyDown("Space")) {
            return true;
        }
        else {
            return false;
        }
    }
}
