// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * Amazing Rock, Paper, Scissors Maze
 * 
 * @author: Nicolas Bergeron
 * 
 * Vanier College 2019 
 */
public class Scissors extends Actor
{

    /**
     * Act - do whatever the Scissors wants to do. This method is called whenever the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        cut();
    }

    /**
     * 
     */
    public boolean isTouchingPaperPlayer()
    {
        if (isTouching(PaperPlayer.class)) {
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * 
     */
    public void cut()
    {
        if (isTouchingPaperPlayer()) {
            removeTouching(PaperPlayer.class);
            int currentx = getX();
            int currenty = getY();
            World world = getWorld();
            ScissorsPlayer scissorsPlayer =  new ScissorsPlayer();
            world.addObject(scissorsPlayer, currentx, currenty);
            world.removeObject(this);
            Greenfoot.playSound("cut.wav");
        }
    }
}
