// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class StartScreen extends World
{
    private GreenfootSound game_music =  new GreenfootSound("Starting.wav");
    public int counter = 90;

    /**
     * Constructor for objects of class StartScreen.
     */
    public StartScreen()
    {
        super(900, 750, 1);
        prepare();
    }

    /**
     * 
     */
    public void started()
    {
        game_music.playLoop();
    }

    /**
     * 
     */
    public void stopped()
    {
        game_music.stop();
    }

    /**
     * 
     */
    public void act()
    {
        showTxt();
        if (isSpacePressed()) {
            World howTPWorld =  new HowToPlayScreen();
            Greenfoot.setWorld(howTPWorld);
            stopped();
            howTPWorld.started();
        }
    }

    /**
     * 
     */
    public boolean isSpacePressed()
    {
        if (Greenfoot.isKeyDown("Space")) {
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * 
     */
    public void showTxt()
    {
        if (counter > 0) {
            this.showText("Press Space to Continue", 450, 530);
        }
        else {
            this.showText("", 450, 530);
        }
        counter = counter - 1;
        
        if (counter < -90) {
            counter = 90;
        }
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
    }
}
