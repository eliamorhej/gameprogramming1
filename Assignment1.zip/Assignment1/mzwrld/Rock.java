// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * Amazing Rock, Paper, Scissors Maze
 * 
 * @author: Nicolas Bergeron
 * 
 * Vanier College 2019 
 */
public class Rock extends Actor
{

    /**
     * Act - do whatever the Rock wants to do. This method is called whenever the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        crush();
    }

    /**
     * 
     */
    public boolean isTouchingScissorsPlayer()
    {
        if (isTouching(ScissorsPlayer.class)) {
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * 
     */
    public void crush()
    {
        if (isTouchingScissorsPlayer()) {
            removeTouching(ScissorsPlayer.class);
            int currentx = getX();
            int currenty = getY();
            World world = getWorld();
            RockPlayer rockPlayer =  new RockPlayer();
            world.addObject(rockPlayer, currentx, currenty);
            world.removeObject(this);
            Greenfoot.playSound("crush.wav");
        }
    }
}
