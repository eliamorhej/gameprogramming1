// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class Key extends Actor
{

    /**
     * Act - do whatever the Key wants to do. This method is called whenever the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        if (isTouchingPlayer()) {
            World world = getWorld();
            Goal goal =  new Goal();
            world.addObject(goal, 1, 7);
            world.removeObject(this);
        }
    }

    /**
     * 
     */
    public boolean isTouchingPlayer()
    {
        if (isTouching(Player.class)) {
            return true;
        }
        else {
            return false;
        }
    }
}
