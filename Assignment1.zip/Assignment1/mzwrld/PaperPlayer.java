// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * Amazing Rock, Paper, Scissors Maze
 * 
 * @author: Nicolas Bergeron
 * 
 * Vanier College 2019 
 */
public class PaperPlayer extends Player
{

    /**
     * Act - do whatever the PaperPlayer wants to do. This method is called whenever the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        moveAround();
        cover();
    }

    /**
     * 
     */
    public boolean isTouchingRock()
    {
        if (isTouching(Rock.class)) {
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * 
     */
    public void cover()
    {
        if (isTouchingRock()) {
            removeTouching(Rock.class);
            Greenfoot.playSound("cover.wav");
        }
    }
}
