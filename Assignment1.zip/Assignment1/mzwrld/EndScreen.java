// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class EndScreen extends World
{
    private GreenfootSound game_music =  new GreenfootSound("End.wav");
    private int counter = 90;

    /**
     * Constructor for objects of class EndScreen.
     */
    public EndScreen()
    {
        super(900, 750, 1);
    }

    /**
     * 
     */
    public void act()
    {
        showTxt();
        if (isSpacePressed()) {
            World newWorld =  new MazeWorld();
            Greenfoot.setWorld(newWorld);
            stopped();
            newWorld.started();
        }
    }

    /**
     * 
     */
    public boolean isSpacePressed()
    {
        if (Greenfoot.isKeyDown("Space")) {
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * 
     */
    public void showTxt()
    {
        if (counter > 0) {
            this.showText("Press Space to Play Again!", 450, 530);
        }
        else {
            this.showText("", 450, 530);
        }
        counter = counter - 1;
        
        if (counter < -90) {
            counter = 90;
        }
    }

    /**
     * 
     */
    public void started()
    {
        game_music.playLoop();
    }

    /**
     * 
     */
    public void stopped()
    {
        game_music.stop();
    }
}
